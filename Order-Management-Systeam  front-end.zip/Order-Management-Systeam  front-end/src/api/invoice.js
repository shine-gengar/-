import request from './request';

// 开票管理API
const invoiceApi = {
  // 开票录入
  addInvoice: (data) => {
    return request('api/invoices', {
      method: 'POST',
      data
    });
  },
  
  // 欠票查询
  getInvoiceQuery: (params) => {
    return request('api/invoices/query', {
      method: 'GET',
      data: params
    });
  },
  
  // 合同开票详情
  getContractInvoices: (id) => {
    if (!id) {
      return Promise.reject(new Error('合同ID不能为空'));
    }
    return request(`api/invoices/contract/${id}`);
  }
};

export default invoiceApi;