import request from './request';

// 公共字典API
const dictApi = {
  // 行业列表
  getIndustries: () => {
    return request('api/dicts/industries');
  },
  
  // 客户类型列表
  getCustomerTypes: () => {
    return request('api/dicts/customer-types');
  },
  
  // 合同类型列表
  getContractTypes: () => {
    return request('api/dicts/contract-types');
  }
};

export default dictApi;