// API请求配置
const baseURL = 'https://ljcqhetslpin.sealoshzh.site/'; // 后端API基础地址

// 请求拦截器
uni.addInterceptor({
  returnValue (res) {
    // 对响应数据进行处理
    if (res && res.code && res.code !== 200) {
      uni.showToast({
        title: res.message || '请求失败',
        icon: 'none'
      });
    }
    return res;
  }
});

// 通用请求方法
const request = (url, options = {}) => {
  return new Promise((resolve, reject) => {
    uni.request({
      url: baseURL + url,
      method: options.method || 'GET',
      data: options.data || {},
      header: {
        'Content-Type': 'application/json',
        ...options.header
      },
      success: (res) => {
        if (res.statusCode === 200) {
          resolve(res.data);
        } else {
          reject(res);
        }
      },
      fail: (err) => {
        uni.showToast({
          title: '网络错误，请稍后重试',
          icon: 'none'
        });
        reject(err);
      }
    });
  });
};

// 导出请求方法
export default request;