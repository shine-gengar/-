import customerApi from './customer';
import contractApi from './contract';
import invoiceApi from './invoice';
import dictApi from './dict';

// 统一导出所有API
export {
  customerApi,
  contractApi,
  invoiceApi,
  dictApi
};