import request from './request';

// 客户管理API
const customerApi = {
  // 客户列表查询
  getCustomerList: (params) => {
    return request('api/customers', {
      method: 'GET',
      data: params
    });
  },
  
  // 客户详情
  getCustomerDetail: (id) => {
    if (!id) {
      return Promise.reject(new Error('客户ID不能为空'));
    }
    return request(`api/customers/${id}`);
  },
  
  // 新增客户
  addCustomer: (data) => {
    return request('api/customers', {
      method: 'POST',
      data
    });
  },
  
  // 修改客户
  updateCustomer: (id, data) => {
    if (!id) {
      return Promise.reject(new Error('客户ID不能为空'));
    }
    return request(`api/customers/${id}`, {
      method: 'PUT',
      data
    });
  },
  
  // 删除客户
  deleteCustomer: (id) => {
    if (!id) {
      return Promise.reject(new Error('客户ID不能为空'));
    }
    return request(`api/customers/${id}`, {
      method: 'DELETE'
    });
  },
  
  // 提交客户审批
  submitCustomer: (id) => {
    if (!id) {
      return Promise.reject(new Error('客户ID不能为空'));
    }
    return request(`api/customers/${id}/submit`, {
      method: 'POST'
    });
  },
  
  // 撤销客户申请
  cancelCustomer: (id) => {
    if (!id) {
      return Promise.reject(new Error('客户ID不能为空'));
    }
    return request(`api/customers/${id}/cancel`, {
      method: 'POST'
    });
  },
  
  // 客户审批
  approveCustomer: (id, data) => {
    if (!id) {
      return Promise.reject(new Error('客户ID不能为空'));
    }
    return request(`api/customers/${id}/approve`, {
      method: 'POST',
      data
    });
  },
  
  // 待审批客户列表
  getPendingCustomers: (params) => {
    return request('api/customers/pending', {
      method: 'GET',
      data: params
    });
  },
  
  // 客户选择列表
  getCustomerSelectList: (params) => {
    // 过滤掉空值参数
    const filteredParams = {};
    if (params && params.keyword) {
      filteredParams.keyword = params.keyword;
    }
    return request('api/customers/select', {
      method: 'GET',
      data: filteredParams
    });
  }
};

export default customerApi;