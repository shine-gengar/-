import request from './request';

// 合同管理API
const contractApi = {
  // 合同列表查询
  getContractList: (params) => {
    return request('api/contracts', {
      method: 'GET',
      data: params
    });
  },
  
  // 合同详情
  getContractDetail: (id) => {
    if (!id) {
      return Promise.reject(new Error('合同ID不能为空'));
    }
    return request(`api/contracts/${id}`);
  },
  
  // 新增合同
  addContract: (data) => {
    return request('api/contracts', {
      method: 'POST',
      data
    });
  },
  
  // 修改合同
  updateContract: (id, data) => {
    if (!id) {
      return Promise.reject(new Error('合同ID不能为空'));
    }
    return request(`api/contracts/${id}`, {
      method: 'PUT',
      data
    });
  },
  
  // 删除合同
  deleteContract: (id) => {
    if (!id) {
      return Promise.reject(new Error('合同ID不能为空'));
    }
    return request(`api/contracts/${id}`, {
      method: 'DELETE'
    });
  },
  
  // 提交合同审批
  submitContract: (id) => {
    if (!id) {
      return Promise.reject(new Error('合同ID不能为空'));
    }
    return request(`api/contracts/${id}/submit`, {
      method: 'POST'
    });
  },
  
  // 撤销合同申请
  cancelContract: (id) => {
    if (!id) {
      return Promise.reject(new Error('合同ID不能为空'));
    }
    return request(`api/contracts/${id}/cancel`, {
      method: 'POST'
    });
  },
  
  // 合同审批
  approveContract: (id, data) => {
    if (!id) {
      return Promise.reject(new Error('合同ID不能为空'));
    }
    return request(`api/contracts/${id}/approve`, {
      method: 'POST',
      data
    });
  },
  
  // 待审批合同列表
  getPendingContracts: (params) => {
    return request('api/contracts/pending', {
      method: 'GET',
      data: params
    });
  },
  
  // 合同开票详情
  getContractInvoices: (id) => {
    if (!id) {
      return Promise.reject(new Error('合同ID不能为空'));
    }
    return request(`api/contracts/${id}/invoices`);
  }
};

export default contractApi;