<template>
  <view class="container">
    <!-- 合同详细信息 -->
    <view class="info-section">
      <view class="section-title">合同基本信息</view>
      <view class="info-item">
        <text class="info-label">合同编号：</text>
        <text class="info-value">{{ contract?.contractNo }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">合同名称：</text>
        <text class="info-value">{{ contract?.contractName }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">签订日期：</text>
        <text class="info-value">{{ contract?.signDate }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">交货日期：</text>
        <text class="info-value">{{ contract?.deliveryDate }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">合同类型：</text>
        <text class="info-value">{{ contract?.contractType }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">合同金额：</text>
        <text class="info-value amount">{{ contract?.contractAmount }} 元</text>
      </view>
      <view class="info-item">
        <text class="info-label">客户名称：</text>
        <text class="info-value">{{ contract?.customerName }}</text>
      </view>
    </view>
    
    <!-- 审批操作 -->
    <view class="approve-section">
      <view class="section-title">审批操作</view>
      <view class="form-item">
        <text class="label">审批备注 *</text>
        <textarea v-model="approveForm.remark" placeholder="请输入审批备注" class="textarea"></textarea>
      </view>
      <view class="button-group">
        <button type="default" @click="handleReject" class="button button-reject">驳回</button>
        <button type="primary" @click="handleApprove" class="button button-approve">批准</button>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { contractApi } from '../../api';

// 合同数据
const contract = ref(null);

// 审批表单
const approveForm = reactive({
  remark: ''
});

// 加载状态
const loading = ref(false);

// 合同ID
const contractId = ref('');

// 处理批准
const handleApprove = async () => {
  if (!approveForm.remark) {
    uni.showToast({
      title: '请填写审批备注',
      icon: 'none'
    });
    return;
  }
  
  uni.showModal({
    title: '确认批准',
    content: `确定要批准 ${contract.value?.contractName} 吗？`,
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          await contractApi.approveContract(contractId.value, {
            action: 'approve',
            remark: approveForm.remark
          });
          
          uni.showToast({
            title: '批准成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1500);
        } catch (error) {
          uni.showToast({
            title: '批准失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 处理驳回
const handleReject = async () => {
  if (!approveForm.remark) {
    uni.showToast({
      title: '请填写审批备注',
      icon: 'none'
    });
    return;
  }
  
  uni.showModal({
    title: '确认驳回',
    content: `确定要驳回 ${contract.value?.contractName} 吗？`,
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          await contractApi.approveContract(contractId.value, {
            action: 'reject',
            remark: approveForm.remark
          });
          
          uni.showToast({
            title: '驳回成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1500);
        } catch (error) {
          uni.showToast({
            title: '驳回失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 加载合同详情
const loadContractDetail = async () => {
  const pages = getCurrentPages();
  console.log('pages:', pages);
  
  if (pages.length === 0) {
    uni.showToast({
      title: '页面信息错误',
      icon: 'none'
    });
    setTimeout(() => {
      uni.navigateBack();
    }, 1000);
    return;
  }
  
  const currentPage = pages[pages.length - 1];
  console.log('currentPage:', currentPage);
  console.log('currentPage.options:', currentPage.options);
  
  contractId.value = currentPage.options.id;
  console.log('contractId.value:', contractId.value);
  
  if (!contractId.value) {
    uni.showToast({
      title: '合同ID不存在',
      icon: 'none'
    });
    setTimeout(() => {
      uni.navigateBack();
    }, 1000);
    return;
  }
  
  loading.value = true;
  try {
    const result = await contractApi.getContractDetail(contractId.value);
    contract.value = result.data;
  } catch (error) {
    console.error('加载合同信息失败:', error);
    uni.showToast({
      title: '加载合同信息失败',
      icon: 'none'
    });
    setTimeout(() => {
      uni.navigateBack();
    }, 1000);
  } finally {
    loading.value = false;
  }
};

// 页面加载时获取合同信息
onMounted(async () => {
  // 加载合同详情
  await loadContractDetail();
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.info-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.approve-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.section-title {
  font-size: 28rpx;
  font-weight: 600;
  color: #333;
  margin-bottom: 20rpx;
  padding-bottom: 12rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.info-item {
  display: flex;
  margin-bottom: 16rpx;
  align-items: flex-start;
}

.info-label {
  font-size: 26rpx;
  color: #666;
  width: 140rpx;
  flex-shrink: 0;
}

.info-value {
  font-size: 26rpx;
  color: #333;
  flex: 1;
  line-height: 1.4;
}

.info-value.amount {
  color: #ff4d4f;
  font-weight: 500;
}

.form-item {
  margin-bottom: 30rpx;
}

.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 8rpx;
  font-weight: 500;
}

.textarea {
  width: 100%;
  height: 160rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 20rpx;
  font-size: 28rpx;
  background-color: #fafafa;
  resize: none;
}

.button-group {
  display: flex;
  gap: 20rpx;
}

.button {
  flex: 1;
  height: 80rpx;
  font-size: 28rpx;
  border-radius: 8rpx;
}

.button-reject {
  border: 1rpx solid #ff4d4f;
  color: #ff4d4f;
}

.button-approve {
  background-color: #52c41a;
  color: #fff;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .info-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 4rpx;
  }
  
  .info-label {
    width: auto;
  }
  
  .button-group {
    flex-direction: column;
  }
}
</style>