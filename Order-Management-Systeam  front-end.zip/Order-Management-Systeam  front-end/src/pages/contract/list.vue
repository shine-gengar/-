<template>
  <view class="container">
    <view class="search">
      <input placeholder="合同编号" />
      <input placeholder="客户名称" />
      <button>查询</button>
    </view>
    
    <view class="list">
      <view v-for="item in list" :key="item.id">
        <view>{{ item.contractName }}</view>
        <view>{{ item.contractNo }}</view>
        <view>{{ item.status }}</view>
        <button>编辑</button>
        <button v-if="item.status === '待审批'">审批</button>
      </view>
      <view v-if="list.length === 0">暂无数据</view>
    </view>
    
    <button class="add">新增合同</button>
  </view>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { contractApi } from '../../api';

const list = ref([]);

onMounted(async () => {
  try {
    const res = await contractApi.getContractList();
    list.value = res.data.list;
  } catch (e) {
    uni.showToast({ title: '加载失败', icon: 'none' });
  }
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background: #f5f5f5;
  min-height: 100vh;
}

.search {
  background: #fff;
  padding: 20rpx;
  margin-bottom: 20rpx;
}

input {
  width: 100%;
  height: 70rpx;
  border: 1rpx solid #ddd;
  padding: 0 20rpx;
  margin-bottom: 16rpx;
}

button {
  width: 100%;
  height: 70rpx;
}

.list {
  background: #fff;
  padding: 20rpx;
  margin-bottom: 100rpx;
}

.add {
  position: fixed;
  bottom: 40rpx;
  left: 20rpx;
  right: 20rpx;
  height: 80rpx;
  background: #1890ff;
  color: #fff;
}
</style>