<template>
  <view class="container">
    <form @submit.prevent="handleSubmit" class="form">
      <!-- 合同基本信息 -->
      <view class="form-section">
        <view class="form-item">
          <text class="label">合同编号</text>
          <input type="text" v-model="form.contractNo" placeholder="系统自动生成" class="input" disabled />
        </view>
        
        <view class="form-item">
          <text class="label">合同名称 *</text>
          <input type="text" v-model="form.contractName" placeholder="请输入合同名称" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">签订日期 *</text>
          <input type="date" v-model="form.signDate" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">交货日期 *</text>
          <input type="date" v-model="form.deliveryDate" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">合同类型 *</text>
          <picker @change="handleContractTypeChange" :range="contractTypeOptions" :value="contractTypeIndex" class="picker">
            <view class="picker-text">{{ contractTypeOptions[contractTypeIndex] || '请选择合同类型' }}</view>
          </picker>
        </view>
        
        <view class="form-item">
          <text class="label">合同金额 *</text>
          <input type="number" v-model="form.contractAmount" placeholder="请输入合同金额" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">客户名称 *</text>
          <view class="customer-select" @click="selectCustomer">
            <text class="customer-name">{{ form.customerName || '请选择客户' }}</text>
            <text class="select-arrow">→</text>
          </view>
        </view>
      </view>
      
      <!-- 操作按钮 -->
      <view class="button-group">
        <button type="default" @click="handleCancel" class="button button-cancel">撤销</button>
        <button type="default" @click="handleDelete" class="button button-delete">删除</button>
        <button type="default" @click="handleSave" class="button button-save">保存</button>
        <button type="primary" @click="handleSubmit" class="button button-submit">提交</button>
      </view>
    </form>
  </view>
</template>

<script setup>
import { ref, reactive, onMounted, computed } from 'vue';
import { contractApi, dictApi } from '../../api';

// 表单数据
const form = reactive({
  contractNo: '',
  contractName: '',
  signDate: '',
  deliveryDate: '',
  contractType: '',
  contractAmount: '',
  customerName: '',
  customerId: ''
});

// 合同类型选项
const contractTypeOptions = ref([]);

// 合同类型选择索引
const contractTypeIndex = ref(0);

// 合同ID（用于编辑模式）
const contractId = ref('');

// 加载状态
const loading = ref(false);

// 计算合同编号前缀
const contractPrefix = computed(() => {
  const type = form.contractType;
  switch (type) {
    case '产品销售合同':
      return 'C';
    case '服务合同':
      return 'S';
    case '采购合同':
      return 'P';
    default:
      return 'O';
  }
});

// 生成合同编号（前端临时生成，实际以后端为准）
const generateContractNo = () => {
  if (!form.contractType) return;
  
  const prefix = contractPrefix.value;
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const randomNum = String(Math.floor(Math.random() * 1000)).padStart(3, '0');
  
  form.contractNo = `${prefix}${year}${month}${randomNum}`;
};

// 处理合同类型选择
const handleContractTypeChange = (e) => {
  contractTypeIndex.value = e.detail.value;
  form.contractType = contractTypeOptions.value[e.detail.value];
  generateContractNo();
};

// 选择客户
const selectCustomer = () => {
  // 跳转到客户选择页面
  uni.navigateTo({
    url: '/pages/customer/select'
  });
};

// 处理保存
const handleSave = async () => {
  // 验证表单
  if (!validateForm()) return;
  
  loading.value = true;
  try {
    let result;
    const contractData = {
      contractName: form.contractName,
      signDate: form.signDate,
      deliveryDate: form.deliveryDate,
      contractType: form.contractType,
      contractAmount: parseFloat(form.contractAmount),
      customerId: form.customerId
    };
    
    if (contractId.value) {
      // 修改合同
      result = await contractApi.updateContract(contractId.value, contractData);
    } else {
      // 新增合同
      result = await contractApi.addContract(contractData);
      contractId.value = result.data.id;
      form.contractNo = result.data.contractNo;
    }
    
    uni.showToast({
      title: '保存成功',
      icon: 'success'
    });
  } catch (error) {
    uni.showToast({
      title: '保存失败，请稍后重试',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 处理提交
const handleSubmit = async () => {
  // 验证表单
  if (!validateForm()) return;
  
  loading.value = true;
  try {
    // 先保存合同信息
    let result;
    const contractData = {
      contractName: form.contractName,
      signDate: form.signDate,
      deliveryDate: form.deliveryDate,
      contractType: form.contractType,
      contractAmount: parseFloat(form.contractAmount),
      customerId: form.customerId
    };
    
    if (contractId.value) {
      result = await contractApi.updateContract(contractId.value, contractData);
    } else {
      result = await contractApi.addContract(contractData);
      contractId.value = result.data.id;
      form.contractNo = result.data.contractNo;
    }
    
    // 提交审批
    await contractApi.submitContract(contractId.value);
    
    uni.showToast({
      title: '提交成功，进入审批流程',
      icon: 'success'
    });
    
    // 提交后跳转
    setTimeout(() => {
      uni.navigateBack();
    }, 1500);
  } catch (error) {
    uni.showToast({
      title: '提交失败，请稍后重试',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 处理撤销
const handleCancel = async () => {
  if (!contractId.value) {
    uni.navigateBack();
    return;
  }
  
  uni.showModal({
    title: '提示',
    content: '确定要撤销吗？',
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          await contractApi.cancelContract(contractId.value);
          uni.showToast({
            title: '撤销成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1000);
        } catch (error) {
          uni.showToast({
            title: '撤销失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 处理删除
const handleDelete = async () => {
  if (!contractId.value) {
    uni.navigateBack();
    return;
  }
  
  uni.showModal({
    title: '警告',
    content: '确定要删除吗？此操作不可恢复',
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          await contractApi.deleteContract(contractId.value);
          uni.showToast({
            title: '删除成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1000);
        } catch (error) {
          uni.showToast({
            title: '删除失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 表单验证
const validateForm = () => {
  if (!form.contractName) {
    uni.showToast({
      title: '请输入合同名称',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.signDate) {
    uni.showToast({
      title: '请选择签订日期',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.deliveryDate) {
    uni.showToast({
      title: '请选择交货日期',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.contractType) {
    uni.showToast({
      title: '请选择合同类型',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.contractAmount) {
    uni.showToast({
      title: '请输入合同金额',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.customerName) {
    uni.showToast({
      title: '请选择客户',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.customerId) {
    uni.showToast({
      title: '请选择客户',
      icon: 'none'
    });
    return false;
  }
  
  return true;
};

// 加载合同类型列表
const loadContractTypes = async () => {
  try {
    const result = await dictApi.getContractTypes();
    contractTypeOptions.value = result.data;
  } catch (error) {
    console.error('加载合同类型失败:', error);
  }
};

// 加载合同详情（编辑模式）
const loadContractDetail = async () => {
  const pages = getCurrentPages();
  const currentPage = pages[pages.length - 1];
  const { id } = currentPage.options;
  
  if (id) {
    contractId.value = id;
    loading.value = true;
    try {
      const result = await contractApi.getContractDetail(id);
      const contract = result.data;
      
      // 填充表单数据
      form.contractNo = contract.contractNo;
      form.contractName = contract.contractName;
      form.signDate = contract.signDate;
      form.deliveryDate = contract.deliveryDate;
      form.contractType = contract.contractType;
      form.contractAmount = contract.contractAmount;
      form.customerName = contract.customerName;
      
      // 设置合同类型选择索引
      contractTypeIndex.value = contractTypeOptions.value.indexOf(contract.contractType);
    } catch (error) {
      uni.showToast({
        title: '加载合同信息失败',
        icon: 'none'
      });
    } finally {
      loading.value = false;
    }
  }
};

// 页面加载时初始化
onMounted(async () => {
  // 加载合同类型列表
  await loadContractTypes();
  
  // 生成合同编号
  generateContractNo();
  
  // 监听客户选择事件
  uni.$on('customerSelected', (customer) => {
    form.customerName = customer.customerName;
    form.customerId = customer.id;
  });
  
  // 加载合同详情（编辑模式）
  await loadContractDetail();
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.form {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.form-section {
  margin-bottom: 30rpx;
}

.form-item {
  margin-bottom: 24rpx;
}

.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 8rpx;
  font-weight: 500;
}

.input {
  width: 100%;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
  background-color: #fafafa;
}

.picker {
  width: 100%;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  display: flex;
  align-items: center;
  background-color: #fafafa;
}

.picker-text {
  font-size: 28rpx;
  color: #666;
}

.customer-select {
  width: 100%;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #fafafa;
  cursor: pointer;
}

.customer-name {
  font-size: 28rpx;
  color: #666;
}

.select-arrow {
  font-size: 32rpx;
  color: #999;
}

.button-group {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
  margin-top: 40rpx;
}

.button {
  flex: 1;
  min-width: 150rpx;
  height: 80rpx;
  font-size: 28rpx;
  border-radius: 8rpx;
}

.button-cancel {
  border: 1rpx solid #ddd;
  color: #666;
}

.button-delete {
  border: 1rpx solid #ff4d4f;
  color: #ff4d4f;
}

.button-save {
  border: 1rpx solid #1890ff;
  color: #1890ff;
}

.button-submit {
  background-color: #1890ff;
  color: #fff;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .button-group {
    flex-direction: column;
  }
  
  .button {
    width: 100%;
  }
}
</style>