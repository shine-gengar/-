<template>
  <view class="container">
    <view class="header">
      <image class="logo" src="/static/logo.png"></image>
      <text class="title">订单管理系统</text>
    </view>
    
    <view class="menu">
      <view class="menu-item" @click="navigateTo('/pages/customer/list')">
        <view class="menu-icon customer-icon"></view>
        <text class="menu-text">客户管理</text>
      </view>
      <view class="menu-item" @click="navigateTo('/pages/customer/approve-list')">
        <view class="menu-icon approve-icon"></view>
        <text class="menu-text">客户审批</text>
      </view>
      <view class="menu-item" @click="navigateTo('/pages/contract/list')">
        <view class="menu-icon contract-icon"></view>
        <text class="menu-text">合同管理</text>
      </view>
      <view class="menu-item" @click="navigateTo('/pages/invoice/add')">
        <view class="menu-icon invoice-icon"></view>
        <text class="menu-text">开票管理</text>
      </view>
      <view class="menu-item" @click="navigateTo('/pages/invoice/query')">
        <view class="menu-icon query-icon"></view>
        <text class="menu-text">欠票查询</text>
      </view>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      title: '订单管理系统',
    }
  },
  onLoad() {},
  methods: {
    navigateTo(url) {
      uni.navigateTo({
        url: url
      });
    },
    showToast(message) {
      uni.showToast({
        title: message,
        icon: 'none'
      });
    }
  },
}
</script>

<style>
.container {
  padding: 40rpx 20rpx;
  min-height: 100vh;
  background-color: #f5f5f5;
}

.header {
  display: flex;
  flex-direction: column;
  align-items: center;
  margin-bottom: 60rpx;
}

.logo {
  height: 160rpx;
  width: 160rpx;
  margin-bottom: 20rpx;
}

.title {
  font-size: 36rpx;
  font-weight: 600;
  color: #333;
}

.menu {
  display: grid;
  grid-template-columns: repeat(2, 1fr);
  gap: 30rpx;
}

.menu-item {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 40rpx 20rpx;
  display: flex;
  flex-direction: column;
  align-items: center;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
  transition: transform 0.2s;
}

.menu-item:active {
  transform: scale(0.98);
}

.menu-icon {
  width: 100rpx;
  height: 100rpx;
  border-radius: 20rpx;
  margin-bottom: 20rpx;
  display: flex;
  align-items: center;
  justify-content: center;
}

.customer-icon {
  background-color: #e6f7ff;
}

.contract-icon {
  background-color: #f6ffed;
}

.invoice-icon {
  background-color: #fff7e6;
}

.approve-icon {
  background-color: #fff1f0;
}

.query-icon {
  background-color: #f9f0ff;
}

.menu-text {
  font-size: 28rpx;
  color: #333;
  font-weight: 500;
}
</style>
