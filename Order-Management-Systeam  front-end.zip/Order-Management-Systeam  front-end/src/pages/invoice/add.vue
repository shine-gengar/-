<template>
  <view class="container">
    <form @submit.prevent="handleSubmit" class="form">
      <!-- 发票信息 -->
      <view class="form-section">
        <view class="form-item">
          <text class="label">合同号 *</text>
          <view class="contract-select" @click="selectContract">
            <text class="contract-no">{{ selectedContract?.contractNo || '请选择合同' }}</text>
            <text class="select-arrow">→</text>
          </view>
        </view>
        
        <view v-if="selectedContract" class="contract-info">
          <view class="info-row">
            <text class="info-label">合同名称：</text>
            <text class="info-value">{{ selectedContract.contractName }}</text>
          </view>
          <view class="info-row">
            <text class="info-label">客户名称：</text>
            <text class="info-value">{{ selectedContract.customerName }}</text>
          </view>
          <view class="info-row">
            <text class="info-label">合同金额：</text>
            <text class="info-value amount">{{ selectedContract.contractAmount }} 元</text>
          </view>
          <view class="info-row">
            <text class="info-label">已开票金额：</text>
            <text class="info-value">{{ selectedContract.invoicedAmount }} 元</text>
          </view>
          <view class="info-row">
            <text class="info-label">剩余可开票金额：</text>
            <text class="info-value remaining">{{ selectedContract.remainingAmount }} 元</text>
          </view>
        </view>
        
        <view class="form-item">
          <text class="label">本次开票金额 *</text>
          <input type="number" v-model="form.invoiceAmount" placeholder="请输入开票金额" class="input" @input="validateAmount" />
          <text v-if="errorMessage" class="error-message">{{ errorMessage }}</text>
        </view>
        
        <view class="form-item">
          <text class="label">开票日期</text>
          <input type="date" v-model="form.invoiceDate" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">发票备注</text>
          <textarea v-model="form.remark" placeholder="请输入发票备注" class="textarea"></textarea>
        </view>
      </view>
      
      <!-- 操作按钮 -->
      <view class="button-group">
        <button type="default" @click="handleCancel" class="button button-cancel">取消</button>
        <button type="primary" @click="handleSubmit" class="button button-submit">提交</button>
      </view>
    </form>
  </view>
</template>

<script setup>
import { ref, reactive } from 'vue';
import { invoiceApi, contractApi } from '../../api';

// 表单数据
const form = reactive({
  contractId: '',
  invoiceAmount: '',
  invoiceDate: '',
  remark: ''
});

// 选中的合同
const selectedContract = ref(null);

// 合同列表
const contractList = ref([]);

// 错误信息
const errorMessage = ref('');

// 加载状态
const loading = ref(false);

// 选择合同
const selectContract = async () => {
  // 加载合同列表
  loading.value = true;
  try {
    const result = await contractApi.getContractList();
    contractList.value = result.data.list;
    
    // 显示合同选择
    uni.showActionSheet({
      itemList: contractList.value.map(contract => `${contract.contractNo} - ${contract.contractName}`),
      success: async (res) => {
        const selected = contractList.value[res.tapIndex];
        const contractId = selected.id || selected._id;
        form.contractId = contractId;
        
        // 加载合同开票详情
        await loadContractInvoices(contractId);
        errorMessage.value = '';
      }
    });
  } catch (error) {
    uni.showToast({
      title: '加载合同列表失败',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 加载合同开票详情
const loadContractInvoices = async (contractId) => {
  loading.value = true;
  try {
    const result = await invoiceApi.getContractInvoices(contractId);
    selectedContract.value = {
      ...result.data,
      contractName: contractList.value.find(c => c.id === contractId || c._id === contractId)?.contractName || '',
      customerName: contractList.value.find(c => c.id === contractId || c._id === contractId)?.customerName || ''
    };
  } catch (error) {
    uni.showToast({
      title: '加载合同详情失败',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 验证金额
const validateAmount = () => {
  if (!selectedContract.value) {
    errorMessage.value = '请先选择合同';
    return false;
  }
  
  const amount = parseFloat(form.invoiceAmount);
  if (isNaN(amount) || amount <= 0) {
    errorMessage.value = '请输入有效的开票金额';
    return false;
  }
  
  if (amount > selectedContract.value.remainingAmount) {
    errorMessage.value = `开票金额不能超过剩余可开票金额 ${selectedContract.value.remainingAmount} 元`;
    return false;
  }
  
  errorMessage.value = '';
  return true;
};

// 处理提交
const handleSubmit = async () => {
  // 验证表单
  if (!selectedContract.value) {
    uni.showToast({
      title: '请选择合同',
      icon: 'none'
    });
    return;
  }
  
  if (!validateAmount()) {
    return;
  }
  
  uni.showModal({
    title: '确认提交',
    content: `确定要为合同 ${selectedContract.value.contractNo} 开票 ${form.invoiceAmount} 元吗？`,
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          const invoiceData = {
            contractId: form.contractId,
            invoiceAmount: parseFloat(form.invoiceAmount),
            invoiceDate: form.invoiceDate,
            remark: form.remark
          };
          
          await invoiceApi.addInvoice(invoiceData);
          
          uni.showToast({
            title: '开票成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1500);
        } catch (error) {
          uni.showToast({
            title: '开票失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 处理取消
const handleCancel = () => {
  uni.showModal({
    title: '提示',
    content: '确定要取消吗？未保存的数据将丢失',
    success: (res) => {
      if (res.confirm) {
        uni.navigateBack();
      }
    }
  });
};
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.form {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.form-section {
  margin-bottom: 30rpx;
}

.form-item {
  margin-bottom: 24rpx;
}

.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 8rpx;
  font-weight: 500;
}

.input {
  width: 100%;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
  background-color: #fafafa;
}

.textarea {
  width: 100%;
  height: 160rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 20rpx;
  font-size: 28rpx;
  background-color: #fafafa;
  resize: none;
}

.contract-select {
  width: 100%;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #fafafa;
  cursor: pointer;
}

.contract-no {
  font-size: 28rpx;
  color: #666;
}

.select-arrow {
  font-size: 32rpx;
  color: #999;
}

.contract-info {
  background-color: #f5f5f5;
  border-radius: 8rpx;
  padding: 20rpx;
  margin-bottom: 24rpx;
}

.info-row {
  display: flex;
  margin-bottom: 12rpx;
  align-items: center;
}

.info-row:last-child {
  margin-bottom: 0;
}

.info-label {
  font-size: 24rpx;
  color: #666;
  width: 140rpx;
  flex-shrink: 0;
}

.info-value {
  font-size: 24rpx;
  color: #333;
  flex: 1;
}

.info-value.amount {
  color: #ff4d4f;
  font-weight: 500;
}

.info-value.remaining {
  color: #52c41a;
  font-weight: 500;
}

.error-message {
  font-size: 24rpx;
  color: #ff4d4f;
  margin-top: 8rpx;
  display: block;
}

.button-group {
  display: flex;
  gap: 20rpx;
  margin-top: 40rpx;
}

.button {
  flex: 1;
  height: 80rpx;
  font-size: 28rpx;
  border-radius: 8rpx;
}

.button-cancel {
  border: 1rpx solid #ddd;
  color: #666;
}

.button-submit {
  background-color: #1890ff;
  color: #fff;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .info-row {
    flex-direction: column;
    align-items: flex-start;
    gap: 4rpx;
  }
  
  .info-label {
    width: auto;
  }
  
  .button-group {
    flex-direction: column;
  }
}
</style>