<template>
  <view class="container">
    <!-- 搜索区域 -->
    <view class="search-section">
      <input type="text" v-model="searchForm.contractNo" placeholder="合同编号" class="search-input" />
      <input type="text" v-model="searchForm.customerName" placeholder="客户名称" class="search-input" />
      <button type="primary" @click="handleSearch" class="search-button">查询</button>
    </view>
    
    <!-- 欠票列表 -->
    <view class="list-section">
      <view v-for="contract in contractList" :key="contract.id" class="contract-item">
        <view class="contract-header">
          <view class="contract-title">
            <text class="contract-name">{{ contract.contractName }}</text>
            <text class="contract-no">{{ contract.contractNo }}</text>
          </view>
        </view>
        <view class="contract-info">
          <view class="info-row">
            <text class="info-label">客户名称：</text>
            <text class="info-value">{{ contract.customerName }}</text>
          </view>
          <view class="info-row">
            <text class="info-label">合同金额：</text>
            <text class="info-value amount">{{ contract.contractAmount }} 元</text>
          </view>
          <view class="info-row">
            <text class="info-label">已开票金额：</text>
            <text class="info-value">{{ contract.invoicedAmount }} 元</text>
          </view>
          <view class="info-row">
            <text class="info-label">未开票金额：</text>
            <text class="info-value remaining">{{ contract.remainingAmount }} 元</text>
          </view>
        </view>
      </view>
      
      <!-- 空状态 -->
      <view v-if="contractList.length === 0" class="empty-state">
        <text>暂无数据</text>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { invoiceApi } from '../../api';

// 搜索表单
const searchForm = reactive({
  contractNo: '',
  customerName: ''
});

// 合同列表数据
const contractList = ref([]);

// 加载状态
const loading = ref(false);

// 处理查询
const handleSearch = async () => {
  await loadInvoiceQuery();
};

// 加载欠票查询数据
const loadInvoiceQuery = async () => {
  loading.value = true;
  try {
    const result = await invoiceApi.getInvoiceQuery({
      contractNo: searchForm.contractNo,
      customerName: searchForm.customerName
    });
    contractList.value = result.data.list;
  } catch (error) {
    uni.showToast({
      title: '加载欠票查询失败',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 页面加载时初始化
onMounted(async () => {
  // 加载欠票查询数据
  await loadInvoiceQuery();
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.search-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.search-input {
  width: 100%;
  height: 70rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  font-size: 26rpx;
  margin-bottom: 16rpx;
  background-color: #fafafa;
}

.search-button {
  width: 100%;
  height: 70rpx;
  font-size: 28rpx;
  border-radius: 8rpx;
}

.list-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.contract-item {
  border-bottom: 1rpx solid #f0f0f0;
  padding: 20rpx 0;
}

.contract-item:last-child {
  border-bottom: none;
}

.contract-header {
  margin-bottom: 16rpx;
}

.contract-title {
  flex: 1;
}

.contract-name {
  display: block;
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
  margin-bottom: 8rpx;
}

.contract-no {
  font-size: 24rpx;
  color: #666;
}

.contract-info {
  margin-bottom: 16rpx;
}

.info-row {
  display: flex;
  margin-bottom: 12rpx;
  align-items: center;
}

.info-row:last-child {
  margin-bottom: 0;
}

.info-label {
  font-size: 24rpx;
  color: #666;
  width: 140rpx;
  flex-shrink: 0;
}

.info-value {
  font-size: 24rpx;
  color: #333;
  flex: 1;
}

.info-value.amount {
  color: #ff4d4f;
  font-weight: 500;
}

.info-value.remaining {
  color: #52c41a;
  font-weight: 500;
}

.empty-state {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .info-row {
    flex-direction: column;
    align-items: flex-start;
    gap: 4rpx;
  }
  
  .info-label {
    width: auto;
  }
}
</style>