<template>
  <view class="container">
    <!-- 搜索区域 -->
    <view class="search-section">
      <input type="text" v-model="searchForm.customerName" placeholder="客户名称" class="search-input" />
      <input type="text" v-model="searchForm.customerShortName" placeholder="客户简称" class="search-input" />
      <picker @change="handleIndustryChange" :range="industryOptions" :value="industryIndex" class="search-picker">
        <view class="picker-text">{{ industryOptions[industryIndex] || '行业' }}</view>
      </picker>
      <picker @change="handleCustomerTypeChange" :range="customerTypeOptions" :value="customerTypeIndex" class="search-picker">
        <view class="picker-text">{{ customerTypeOptions[customerTypeIndex] || '客户类型' }}</view>
      </picker>
      <button type="primary" @click="handleSearch" class="search-button">查询</button>
    </view>
    
    <!-- 客户列表 -->
    <view class="list-section">
      <view v-for="customer in customerList" :key="customer.id" class="customer-item">
        <view class="customer-info">
          <view class="customer-name">{{ customer.customerName }}</view>
          <view class="customer-meta">
            <text class="meta-item">{{ customer.customerShortName }}</text>
            <text class="meta-item">{{ customer.industry }}</text>
            <text class="meta-item">{{ customer.customerType }}</text>
          </view>
          <view class="customer-contact">
            <text class="contact-item">{{ customer.contactPerson }}</text>
            <text class="contact-item">{{ customer.contactPhone }}</text>
          </view>
          <view class="customer-address">{{ customer.customerAddress }}</view>
        </view>
        <view class="customer-actions">
          <button type="default" @click="handleEdit(customer)" class="action-button">编辑</button>
          <button type="primary" @click="handleView(customer)" class="action-button">查看</button>
          <button v-if="customer.status === '待审批'" type="primary" @click="handleApprove(customer)" class="action-button approve-button">审批</button>
        </view>
      </view>
      
      <!-- 空状态 -->
      <view v-if="customerList.length === 0" class="empty-state">
        <text>暂无客户数据</text>
      </view>
    </view>
    
    <!-- 新增按钮 -->
    <button type="primary" @click="handleAdd" class="add-button">新增客户</button>
  </view>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { customerApi, dictApi } from '../../api';

// 搜索表单
const searchForm = reactive({
  customerName: '',
  customerShortName: '',
  industry: '',
  customerType: ''
});

// 下拉选项
const industryOptions = ref(['信息技术', '金融服务', '制造业', '零售', '医疗健康', '教育', '其他']);
const customerTypeOptions = ref(['企业客户', '个人客户', '政府客户', '其他']);

// 下拉选择索引
const industryIndex = ref(0);
const customerTypeIndex = ref(0);

// 客户列表数据
const customerList = ref([]);
const loading = ref(false);

// 处理行业选择
const handleIndustryChange = (e) => {
  industryIndex.value = e.detail.value;
  searchForm.industry = industryOptions.value[e.detail.value];
};

// 处理客户类型选择
const handleCustomerTypeChange = (e) => {
  customerTypeIndex.value = e.detail.value;
  searchForm.customerType = customerTypeOptions.value[e.detail.value];
};

// 处理查询
const handleSearch = async () => {
  await loadCustomerList();
};

// 处理新增
const handleAdd = () => {
  uni.navigateTo({
    url: '/pages/customer/apply'
  });
};

// 处理编辑
const handleEdit = (customer) => {
  // 确保获取到正确的客户ID
  const id = customer.id || customer._id || customer.ID;
  
  if (!id) {
    uni.showToast({
      title: '客户ID不存在',
      icon: 'none'
    });
    return;
  }
  
  uni.navigateTo({
    url: `/pages/customer/apply?id=${id}`
  });
};

// 处理查看
const handleView = (customer) => {
  uni.showModal({
    title: customer.customerName,
    content: `简称: ${customer.customerShortName}\n行业: ${customer.industry}\n类型: ${customer.customerType}\n联系人: ${customer.contactPerson}\n电话: ${customer.contactPhone}\n地址: ${customer.customerAddress}`,
    showCancel: false
  });
};

// 处理审批
const handleApprove = (customer) => {
  // 确保获取到正确的客户ID
  const id = customer.id || customer._id || customer.ID;
  
  if (!id) {
    uni.showToast({
      title: '客户ID不存在',
      icon: 'none'
    });
    return;
  }
  
  uni.navigateTo({
    url: `/pages/customer/approve-detail?id=${id}`
  });
};

// 加载客户列表
const loadCustomerList = async () => {
  loading.value = true;
  try {
    const response = await customerApi.getCustomerList(searchForm);
    if (response.code === 200) {
      customerList.value = response.data.list;
      uni.showToast({
        title: `查询到 ${response.data.total} 条记录`,
        icon: 'success'
      });
    }
  } catch (error) {
    console.error('查询客户失败:', error);
  } finally {
    loading.value = false;
  }
};

// 获取字典数据
const getDictData = async () => {
  try {
    // 加载行业列表
    const industryResult = await dictApi.getIndustries();
    if (industryResult.code === 200) {
      industryOptions.value = industryResult.data;
    }
    
    // 加载客户类型列表
    const customerTypeResult = await dictApi.getCustomerTypes();
    if (customerTypeResult.code === 200) {
      customerTypeOptions.value = customerTypeResult.data;
    }
  } catch (error) {
    console.error('加载字典数据失败:', error);
  }
};

// 页面加载时初始化
onMounted(async () => {
  // 获取字典数据
  await getDictData();
  
  // 加载客户列表
  await loadCustomerList();
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.search-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.search-input {
  width: 100%;
  height: 70rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  font-size: 26rpx;
  margin-bottom: 16rpx;
  background-color: #fafafa;
}

.search-picker {
  width: 100%;
  height: 70rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  display: flex;
  align-items: center;
  margin-bottom: 16rpx;
  background-color: #fafafa;
}

.picker-text {
  font-size: 26rpx;
  color: #666;
}

.search-button {
  width: 100%;
  height: 70rpx;
  font-size: 28rpx;
  border-radius: 8rpx;
}

.list-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
  margin-bottom: 100rpx;
}

.customer-item {
  border-bottom: 1rpx solid #f0f0f0;
  padding: 20rpx 0;
}

.customer-item:last-child {
  border-bottom: none;
}

.customer-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
  margin-bottom: 12rpx;
}

.customer-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
  margin-bottom: 12rpx;
}

.meta-item {
  font-size: 24rpx;
  color: #666;
  background-color: #f5f5f5;
  padding: 4rpx 12rpx;
  border-radius: 4rpx;
}

.customer-contact {
  display: flex;
  gap: 20rpx;
  margin-bottom: 12rpx;
}

.contact-item {
  font-size: 24rpx;
  color: #666;
}

.customer-address {
  font-size: 24rpx;
  color: #666;
  line-height: 1.4;
  margin-bottom: 16rpx;
}

.customer-actions {
  display: flex;
  gap: 12rpx;
  justify-content: flex-end;
}

.action-button {
  flex: 1;
  max-width: 120rpx;
  height: 60rpx;
  font-size: 24rpx;
  border-radius: 8rpx;
}

.approve-button {
  background-color: #52c41a;
}

.empty-state {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}

.add-button {
  position: fixed;
  bottom: 40rpx;
  left: 20rpx;
  right: 20rpx;
  height: 80rpx;
  font-size: 28rpx;
  border-radius: 40rpx;
  background-color: #1890ff;
  color: #fff;
  box-shadow: 0 4rpx 12rpx rgba(24, 144, 255, 0.4);
}

/* 响应式设计 */
@media (max-width: 768px) {
  .customer-actions {
    flex-direction: column;
  }
  
  .action-button {
    max-width: none;
    width: 100%;
  }
}
</style>