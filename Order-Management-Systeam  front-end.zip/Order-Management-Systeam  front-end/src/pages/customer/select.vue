<template>
  <view class="container">
    <!-- 搜索区域 -->
    <view class="search-section">
      <input type="text" v-model="searchKeyword" placeholder="搜索客户名称、简称、联系人" class="search-input" @input="handleSearch" />
    </view>
    
    <!-- 客户列表 -->
    <view class="list-section">
      <view v-for="customer in customerList" :key="customer.id" class="customer-item" @click="selectCustomer(customer)">
        <view class="customer-info">
          <view class="customer-name">{{ customer.customerName }}</view>
          <view class="customer-meta">
            <text class="meta-item">{{ customer.customerShortName }}</text>
            <text class="meta-item">{{ customer.industry }}</text>
            <text class="meta-item">{{ customer.customerType }}</text>
          </view>
          <view class="customer-contact">
            <text class="contact-item">{{ customer.contactPerson }}</text>
            <text class="contact-item">{{ customer.contactPhone }}</text>
          </view>
        </view>
        <view class="select-icon">→</view>
      </view>
      
      <!-- 空状态 -->
      <view v-if="customerList.length === 0" class="empty-state">
        <text>暂无客户数据</text>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { customerApi } from '../../api';

// 搜索关键词
const searchKeyword = ref('');

// 客户列表数据
const customerList = ref([]);

// 加载状态
const loading = ref(false);

// 处理搜索
const handleSearch = async () => {
  await loadCustomerList();
};

// 选择客户
const selectCustomer = (customer) => {
  // 返回上一页并传递客户信息
  uni.navigateBack({
    delta: 1,
    success: () => {
      // 触发自定义事件，通知上一页选择了客户
      uni.$emit('customerSelected', customer);
    }
  });
};

// 加载客户列表
const loadCustomerList = async () => {
  loading.value = true;
  try {
    const result = await customerApi.getCustomerSelectList({
      keyword: searchKeyword.value
    });
    customerList.value = result.data;
  } catch (error) {
    uni.showToast({
      title: '加载客户列表失败',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 页面加载时初始化
onMounted(async () => {
  // 加载客户列表
  await loadCustomerList();
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.search-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.search-input {
  width: 100%;
  height: 70rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  font-size: 26rpx;
  background-color: #fafafa;
}

.list-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.customer-item {
  display: flex;
  align-items: center;
  padding: 20rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
  cursor: pointer;
}

.customer-item:last-child {
  border-bottom: none;
}

.customer-info {
  flex: 1;
}

.customer-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
  margin-bottom: 8rpx;
}

.customer-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 12rpx;
  margin-bottom: 8rpx;
}

.meta-item {
  font-size: 22rpx;
  color: #666;
  background-color: #f5f5f5;
  padding: 4rpx 10rpx;
  border-radius: 4rpx;
}

.customer-contact {
  display: flex;
  gap: 16rpx;
}

.contact-item {
  font-size: 22rpx;
  color: #666;
}

.select-icon {
  font-size: 32rpx;
  color: #999;
  margin-left: 20rpx;
}

.empty-state {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .customer-meta {
    flex-direction: column;
    gap: 8rpx;
  }
  
  .customer-contact {
    flex-direction: column;
    gap: 8rpx;
  }
}
</style>