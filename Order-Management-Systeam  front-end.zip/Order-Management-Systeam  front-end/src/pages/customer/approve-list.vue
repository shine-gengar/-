<template>
  <view class="container">
    <!-- 待审批客户列表 -->
    <view class="list-section">
      <view v-for="customer in pendingCustomers" :key="customer.id" class="customer-item" @click="navigateToDetail(customer)">
        <view class="customer-info">
          <view class="customer-header">
            <view class="customer-name">{{ customer.customerName }}</view>
            <view class="status-tag pending">待审批</view>
          </view>
          <view class="customer-meta">
            <text class="meta-item">{{ customer.customerShortName }}</text>
            <text class="meta-item">{{ customer.industry }}</text>
            <text class="meta-item">{{ customer.customerType }}</text>
          </view>
          <view class="customer-contact">
            <text class="contact-item">{{ customer.contactPerson }}</text>
            <text class="contact-item">{{ customer.contactPhone }}</text>
          </view>
          <view class="customer-address">{{ customer.customerAddress }}</view>
        </view>
        <view class="arrow-icon">→</view>
      </view>
      
      <!-- 空状态 -->
      <view v-if="pendingCustomers.length === 0" class="empty-state">
        <text>暂无待审批的客户申请</text>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { customerApi } from '../../api';

// 待审批客户数据
const pendingCustomers = ref([]);

// 加载状态
const loading = ref(false);

// 导航到审批详情页
const navigateToDetail = (customer) => {
  uni.navigateTo({
    url: `/pages/customer/approve-detail?id=${customer.id}`
  });
};

// 加载待审批客户列表
const loadPendingCustomers = async () => {
  loading.value = true;
  try {
    const result = await customerApi.getPendingCustomers();
    pendingCustomers.value = result.data.list;
  } catch (error) {
    uni.showToast({
      title: '加载待审批客户失败',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 页面加载时初始化
onMounted(async () => {
  // 加载待审批客户列表
  await loadPendingCustomers();
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.list-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.customer-item {
  display: flex;
  align-items: center;
  padding: 20rpx 0;
  border-bottom: 1rpx solid #f0f0f0;
  cursor: pointer;
}

.customer-item:last-child {
  border-bottom: none;
}

.customer-info {
  flex: 1;
}

.customer-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12rpx;
}

.customer-name {
  font-size: 32rpx;
  font-weight: 600;
  color: #333;
}

.status-tag {
  padding: 4rpx 12rpx;
  border-radius: 4rpx;
  font-size: 22rpx;
  font-weight: 500;
}

.status-tag.pending {
  background-color: #fff7e6;
  color: #fa8c16;
}

.customer-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
  margin-bottom: 12rpx;
}

.meta-item {
  font-size: 24rpx;
  color: #666;
  background-color: #f5f5f5;
  padding: 4rpx 12rpx;
  border-radius: 4rpx;
}

.customer-contact {
  display: flex;
  gap: 20rpx;
  margin-bottom: 12rpx;
}

.contact-item {
  font-size: 24rpx;
  color: #666;
}

.customer-address {
  font-size: 24rpx;
  color: #666;
  line-height: 1.4;
}

.arrow-icon {
  font-size: 32rpx;
  color: #999;
  margin-left: 20rpx;
}

.empty-state {
  text-align: center;
  padding: 100rpx 0;
  color: #999;
  font-size: 28rpx;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .customer-header {
    flex-direction: column;
    align-items: flex-start;
    gap: 8rpx;
  }
  
  .status-tag {
    align-self: flex-start;
  }
}
</style>