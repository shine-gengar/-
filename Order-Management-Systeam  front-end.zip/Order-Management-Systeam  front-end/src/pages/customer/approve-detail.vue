<template>
  <view class="container">
    <!-- 客户详细信息 -->
    <view class="info-section">
      <view class="section-title">客户基本信息</view>
      <view class="info-item">
        <text class="info-label">客户名称：</text>
        <text class="info-value">{{ customer?.customerName }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">客户简称：</text>
        <text class="info-value">{{ customer?.customerShortName }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">行业：</text>
        <text class="info-value">{{ customer?.industry }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">客户类型：</text>
        <text class="info-value">{{ customer?.customerType }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">联系人：</text>
        <text class="info-value">{{ customer?.contactPerson }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">联系电话：</text>
        <text class="info-value">{{ customer?.contactPhone }}</text>
      </view>
      <view class="info-item">
        <text class="info-label">客户地址：</text>
        <text class="info-value">{{ customer?.customerAddress }}</text>
      </view>
    </view>
    
    <!-- 审批操作 -->
    <view class="approve-section">
      <view class="section-title">审批操作</view>
      <view class="form-item">
        <text class="label">审批备注 *</text>
        <textarea v-model="approveForm.remark" placeholder="请输入审批备注" class="textarea"></textarea>
      </view>
      <view class="button-group">
        <button type="default" @click="handleReject" class="button button-reject">驳回</button>
        <button type="primary" @click="handleApprove" class="button button-approve">批准</button>
      </view>
    </view>
  </view>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { customerApi } from '../../api';

// 客户数据
const customer = ref(null);

// 审批表单
const approveForm = reactive({
  remark: ''
});

// 加载状态
const loading = ref(false);

// 客户ID
const customerId = ref('');

// 处理批准
const handleApprove = async () => {
  if (!approveForm.remark) {
    uni.showToast({
      title: '请填写审批备注',
      icon: 'none'
    });
    return;
  }
  
  uni.showModal({
    title: '确认批准',
    content: `确定要批准 ${customer.value?.customerName} 的入网申请吗？`,
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          await customerApi.approveCustomer(customerId.value, {
            action: 'approve',
            remark: approveForm.remark
          });
          
          uni.showToast({
            title: '批准成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1500);
        } catch (error) {
          uni.showToast({
            title: '批准失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 处理驳回
const handleReject = async () => {
  if (!approveForm.remark) {
    uni.showToast({
      title: '请填写审批备注',
      icon: 'none'
    });
    return;
  }
  
  uni.showModal({
    title: '确认驳回',
    content: `确定要驳回 ${customer.value?.customerName} 的入网申请吗？`,
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          await customerApi.approveCustomer(customerId.value, {
            action: 'reject',
            remark: approveForm.remark
          });
          
          uni.showToast({
            title: '驳回成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1500);
        } catch (error) {
          uni.showToast({
            title: '驳回失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 加载客户详情
const loadCustomerDetail = async () => {
  const pages = getCurrentPages();
  const currentPage = pages[pages.length - 1];
  customerId.value = currentPage.options.id;
  
  if (!customerId.value) {
    uni.showToast({
      title: '客户ID不存在',
      icon: 'none'
    });
    setTimeout(() => {
      uni.navigateBack();
    }, 1000);
    return;
  }
  
  loading.value = true;
  try {
    const result = await customerApi.getCustomerDetail(customerId.value);
    customer.value = result.data;
  } catch (error) {
    uni.showToast({
      title: '加载客户信息失败',
      icon: 'none'
    });
    setTimeout(() => {
      uni.navigateBack();
    }, 1000);
  } finally {
    loading.value = false;
  }
};

// 页面加载时获取客户信息
onMounted(async () => {
  // 加载客户详情
  await loadCustomerDetail();
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.info-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  margin-bottom: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.approve-section {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.section-title {
  font-size: 28rpx;
  font-weight: 600;
  color: #333;
  margin-bottom: 20rpx;
  padding-bottom: 12rpx;
  border-bottom: 1rpx solid #f0f0f0;
}

.info-item {
  display: flex;
  margin-bottom: 16rpx;
  align-items: flex-start;
}

.info-label {
  font-size: 26rpx;
  color: #666;
  width: 140rpx;
  flex-shrink: 0;
}

.info-value {
  font-size: 26rpx;
  color: #333;
  flex: 1;
  line-height: 1.4;
}

.form-item {
  margin-bottom: 30rpx;
}

.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 8rpx;
  font-weight: 500;
}

.textarea {
  width: 100%;
  height: 160rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 20rpx;
  font-size: 28rpx;
  background-color: #fafafa;
  resize: none;
}

.button-group {
  display: flex;
  gap: 20rpx;
}

.button {
  flex: 1;
  height: 80rpx;
  font-size: 28rpx;
  border-radius: 8rpx;
}

.button-reject {
  border: 1rpx solid #ff4d4f;
  color: #ff4d4f;
}

.button-approve {
  background-color: #52c41a;
  color: #fff;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .info-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 4rpx;
  }
  
  .info-label {
    width: auto;
  }
  
  .button-group {
    flex-direction: column;
  }
}
</style>