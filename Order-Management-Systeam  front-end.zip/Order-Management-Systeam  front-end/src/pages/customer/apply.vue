<template>
  <view class="container">
    <form @submit.prevent="handleSubmit" class="form">
      <!-- 客户基本信息 -->
      <view class="form-section">
        <view class="form-item">
          <text class="label">客户名称 *</text>
          <input type="text" v-model="form.customerName" placeholder="请输入客户名称" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">客户简称</text>
          <input type="text" v-model="form.customerShortName" placeholder="请输入客户简称" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">行业 *</text>
          <picker @change="handleIndustryChange" :range="industryOptions" :value="industryIndex" class="picker">
            <view class="picker-text">{{ industryOptions[industryIndex] || '请选择行业' }}</view>
          </picker>
        </view>
        
        <view class="form-item">
          <text class="label">客户类型 *</text>
          <picker @change="handleCustomerTypeChange" :range="customerTypeOptions" :value="customerTypeIndex" class="picker">
            <view class="picker-text">{{ customerTypeOptions[customerTypeIndex] || '请选择客户类型' }}</view>
          </picker>
        </view>
        
        <view class="form-item">
          <text class="label">联系人 *</text>
          <input type="text" v-model="form.contactPerson" placeholder="请输入联系人" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">联系电话 *</text>
          <input type="number" v-model="form.contactPhone" placeholder="请输入联系电话" class="input" />
        </view>
        
        <view class="form-item">
          <text class="label">客户地址</text>
          <textarea v-model="form.customerAddress" placeholder="请输入客户地址" class="textarea"></textarea>
        </view>
      </view>
      
      <!-- 操作按钮 -->
      <view class="button-group">
        <button type="default" @click="handleCancel" class="button button-cancel">撤销</button>
        <button type="default" @click="handleDelete" class="button button-delete">删除</button>
        <button type="default" @click="handleSave" class="button button-save">保存</button>
        <button type="primary" @click="handleSubmit" class="button button-submit">提交</button>
      </view>
    </form>
  </view>
</template>

<script setup>
import { ref, reactive, onMounted } from 'vue';
import { customerApi, dictApi } from '../../api';

// 表单数据
const form = reactive({
  customerName: '',
  customerShortName: '',
  industry: '',
  customerType: '',
  contactPerson: '',
  contactPhone: '',
  customerAddress: ''
});

// 下拉选项
const industryOptions = ref([]);
const customerTypeOptions = ref([]);

// 下拉选择索引
const industryIndex = ref(0);
const customerTypeIndex = ref(0);

// 客户ID（用于编辑模式）
const customerId = ref('');

// 加载状态
const loading = ref(false);

// 处理行业选择
const handleIndustryChange = (e) => {
  industryIndex.value = e.detail.value;
  form.industry = industryOptions.value[e.detail.value];
};

// 处理客户类型选择
const handleCustomerTypeChange = (e) => {
  customerTypeIndex.value = e.detail.value;
  form.customerType = customerTypeOptions.value[e.detail.value];
};

// 处理保存
const handleSave = async () => {
  // 验证表单
  if (!validateForm()) return;
  
  loading.value = true;
  try {
    let result;
    if (customerId.value) {
      // 修改客户
      result = await customerApi.updateCustomer(customerId.value, form);
    } else {
      // 新增客户
      result = await customerApi.addCustomer(form);
      customerId.value = result.data.id;
    }
    
    uni.showToast({
      title: '保存成功',
      icon: 'success'
    });
  } catch (error) {
    uni.showToast({
      title: '保存失败，请稍后重试',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 处理提交
const handleSubmit = async () => {
  // 验证表单
  if (!validateForm()) return;
  
  loading.value = true;
  try {
    // 先保存客户信息
    let result;
    if (customerId.value) {
      result = await customerApi.updateCustomer(customerId.value, form);
    } else {
      result = await customerApi.addCustomer(form);
      customerId.value = result.data.id;
    }
    
    // 提交审批
    await customerApi.submitCustomer(customerId.value);
    
    uni.showToast({
      title: '提交成功，进入审批流程',
      icon: 'success'
    });
    
    // 提交后跳转
    setTimeout(() => {
      uni.navigateBack();
    }, 1500);
  } catch (error) {
    uni.showToast({
      title: '提交失败，请稍后重试',
      icon: 'none'
    });
  } finally {
    loading.value = false;
  }
};

// 处理撤销
const handleCancel = async () => {
  if (!customerId.value) {
    uni.navigateBack();
    return;
  }
  
  uni.showModal({
    title: '提示',
    content: '确定要撤销吗？',
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          await customerApi.cancelCustomer(customerId.value);
          uni.showToast({
            title: '撤销成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1000);
        } catch (error) {
          uni.showToast({
            title: '撤销失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 处理删除
const handleDelete = async () => {
  if (!customerId.value) {
    uni.navigateBack();
    return;
  }
  
  uni.showModal({
    title: '警告',
    content: '确定要删除吗？此操作不可恢复',
    success: async (res) => {
      if (res.confirm) {
        loading.value = true;
        try {
          await customerApi.deleteCustomer(customerId.value);
          uni.showToast({
            title: '删除成功',
            icon: 'success'
          });
          setTimeout(() => {
            uni.navigateBack();
          }, 1000);
        } catch (error) {
          uni.showToast({
            title: '删除失败，请稍后重试',
            icon: 'none'
          });
        } finally {
          loading.value = false;
        }
      }
    }
  });
};

// 表单验证
const validateForm = () => {
  if (!form.customerName) {
    uni.showToast({
      title: '请输入客户名称',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.industry) {
    uni.showToast({
      title: '请选择行业',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.customerType) {
    uni.showToast({
      title: '请选择客户类型',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.contactPerson) {
    uni.showToast({
      title: '请输入联系人',
      icon: 'none'
    });
    return false;
  }
  
  if (!form.contactPhone) {
    uni.showToast({
      title: '请输入联系电话',
      icon: 'none'
    });
    return false;
  }
  
  return true;
};

// 加载字典数据
const loadDictData = async () => {
  try {
    // 加载行业列表
    const industryResult = await dictApi.getIndustries();
    industryOptions.value = industryResult.data;
    
    // 加载客户类型列表
    const customerTypeResult = await dictApi.getCustomerTypes();
    customerTypeOptions.value = customerTypeResult.data;
  } catch (error) {
    console.error('加载字典数据失败:', error);
  }
};

// 加载客户详情（编辑模式）
const loadCustomerDetail = async () => {
  const pages = getCurrentPages();
  const currentPage = pages[pages.length - 1];
  const { id } = currentPage.options;
  
  console.log('Customer ID in apply.vue:', id);
  
  if (id) {
    customerId.value = id;
    loading.value = true;
    try {
      console.log('Fetching customer detail for ID:', id);
      const result = await customerApi.getCustomerDetail(id);
      console.log('Customer detail result:', result);
      const customer = result.data;
      
      // 填充表单数据
      form.customerName = customer.customerName;
      form.customerShortName = customer.customerShortName;
      form.industry = customer.industry;
      form.customerType = customer.customerType;
      form.contactPerson = customer.contactPerson;
      form.contactPhone = customer.contactPhone;
      form.customerAddress = customer.customerAddress;
      
      // 设置下拉选择索引
      industryIndex.value = industryOptions.value.indexOf(customer.industry);
      customerTypeIndex.value = customerTypeOptions.value.indexOf(customer.customerType);
    } catch (error) {
      console.error('Error loading customer detail:', error);
      uni.showToast({
        title: '加载客户信息失败',
        icon: 'none'
      });
    } finally {
      loading.value = false;
    }
  } else {
    console.log('No customer ID provided');
  }
};

// 页面加载时初始化
onMounted(async () => {
  // 加载字典数据
  await loadDictData();
  
  // 加载客户详情（编辑模式）
  await loadCustomerDetail();
});
</script>

<style scoped>
.container {
  padding: 20rpx;
  background-color: #f5f5f5;
  min-height: 100vh;
}

.form {
  background-color: #fff;
  border-radius: 12rpx;
  padding: 20rpx;
  box-shadow: 0 2rpx 10rpx rgba(0, 0, 0, 0.1);
}

.form-section {
  margin-bottom: 30rpx;
}

.form-item {
  margin-bottom: 24rpx;
}

.label {
  display: block;
  font-size: 28rpx;
  color: #333;
  margin-bottom: 8rpx;
  font-weight: 500;
}

.input {
  width: 100%;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  font-size: 28rpx;
  background-color: #fafafa;
}

.textarea {
  width: 100%;
  height: 160rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 20rpx;
  font-size: 28rpx;
  background-color: #fafafa;
  resize: none;
}

.picker {
  width: 100%;
  height: 80rpx;
  border: 1rpx solid #ddd;
  border-radius: 8rpx;
  padding: 0 20rpx;
  display: flex;
  align-items: center;
  background-color: #fafafa;
}

.picker-text {
  font-size: 28rpx;
  color: #666;
}

.button-group {
  display: flex;
  flex-wrap: wrap;
  gap: 16rpx;
  margin-top: 40rpx;
}

.button {
  flex: 1;
  min-width: 150rpx;
  height: 80rpx;
  font-size: 28rpx;
  border-radius: 8rpx;
}

.button-cancel {
  border: 1rpx solid #ddd;
  color: #666;
}

.button-delete {
  border: 1rpx solid #ff4d4f;
  color: #ff4d4f;
}

.button-save {
  border: 1rpx solid #1890ff;
  color: #1890ff;
}

.button-submit {
  background-color: #1890ff;
  color: #fff;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .button-group {
    flex-direction: column;
  }
  
  .button {
    width: 100%;
  }
}
</style>