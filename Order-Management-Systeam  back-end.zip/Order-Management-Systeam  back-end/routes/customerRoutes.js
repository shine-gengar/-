const express = require('express');
const router = express.Router();
const Customer = require('../models/Customer');

// 客户列表查询
router.get('/', async (req, res) => {
  try {
    const { customerName, customerShortName, industry, customerType, contactPerson, contactPhone, customerAddress, page = 1, pageSize = 10 } = req.query;
    
    const query = {};
    if (customerName) query.customerName = { $regex: customerName, $options: 'i' };
    if (customerShortName) query.customerShortName = { $regex: customerShortName, $options: 'i' };
    if (industry) query.industry = industry;
    if (customerType) query.customerType = customerType;
    if (contactPerson) query.contactPerson = { $regex: contactPerson, $options: 'i' };
    if (contactPhone) query.contactPhone = { $regex: contactPhone, $options: 'i' };
    if (customerAddress) query.customerAddress = { $regex: customerAddress, $options: 'i' };
    
    const total = await Customer.countDocuments(query);
    const list = await Customer.find(query)
      .skip((page - 1) * pageSize)
      .limit(Number(pageSize))
      .sort({ createdAt: -1 });
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        list,
        total,
        page: Number(page),
        pageSize: Number(pageSize)
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 待审批客户列表
router.get('/pending', async (req, res) => {
  try {
    const { page = 1, pageSize = 10 } = req.query;
    
    const total = await Customer.countDocuments({ status: '待审批' });
    const list = await Customer.find({ status: '待审批' })
      .skip((page - 1) * pageSize)
      .limit(Number(pageSize))
      .sort({ createdAt: -1 });
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        list,
        total,
        page: Number(page),
        pageSize: Number(pageSize)
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 客户选择列表
router.get('/select', async (req, res) => {
  try {
    const { keyword } = req.query;
    
    const query = {};
    if (keyword) {
      query.$or = [
        { customerName: { $regex: keyword, $options: 'i' } },
        { customerShortName: { $regex: keyword, $options: 'i' } }
      ];
    }
    
    const customers = await Customer.find(query)
      .select('_id customerName customerShortName industry customerType contactPerson contactPhone')
      .limit(50);
    
    // 将 _id 转换为 id
    const formattedCustomers = customers.map(customer => ({
      id: customer._id,
      customerName: customer.customerName,
      customerShortName: customer.customerShortName,
      industry: customer.industry,
      customerType: customer.customerType,
      contactPerson: customer.contactPerson,
      contactPhone: customer.contactPhone
    }));
    
    res.json({
      code: 200,
      message: 'success',
      data: formattedCustomers
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 客户详情
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // 检查 ID 是否有效
    if (!id || id === 'undefined' || id === 'null') {
      return res.status(400).json({ code: 400, message: '无效的客户 ID', data: null });
    }
    
    let customer;
    try {
      // 尝试按 ObjectId 查找
      customer = await Customer.findById(id);
    } catch (err) {
      // 如果是 ObjectId 格式错误，返回客户不存在
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    
    if (!customer) {
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    res.json({
      code: 200,
      message: 'success',
      data: customer
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 新增客户
router.post('/', async (req, res) => {
  try {
    const { customerName, customerShortName, industry, customerType, contactPerson, contactPhone, customerAddress } = req.body;
    
    // 检查客户名称是否已存在
    const existingCustomer = await Customer.findOne({ customerName });
    if (existingCustomer) {
      return res.status(400).json({ code: 5001, message: '客户名称已存在', data: null });
    }
    
    const customer = new Customer({
      customerName,
      customerShortName,
      industry,
      customerType,
      contactPerson,
      contactPhone,
      customerAddress,
      status: '待审批'
    });
    
    await customer.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: customer._id,
        customerName: customer.customerName,
        status: customer.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 修改客户
router.put('/:id', async (req, res) => {
  try {
    const { customerName, customerShortName, industry, customerType, contactPerson, contactPhone, customerAddress } = req.body;
    
    // 检查客户是否存在
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    
    // 检查客户名称是否已存在（排除当前客户）
    const existingCustomer = await Customer.findOne({ customerName, _id: { $ne: req.params.id } });
    if (existingCustomer) {
      return res.status(400).json({ code: 5001, message: '客户名称已存在', data: null });
    }
    
    // 更新客户信息
    customer.customerName = customerName;
    customer.customerShortName = customerShortName;
    customer.industry = industry;
    customer.customerType = customerType;
    customer.contactPerson = contactPerson;
    customer.contactPhone = contactPhone;
    customer.customerAddress = customerAddress;
    customer.status = '待审批';
    
    await customer.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: customer._id,
        customerName: customer.customerName,
        status: customer.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 删除客户
router.delete('/:id', async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    
    await customer.deleteOne();
    
    res.json({
      code: 200,
      message: 'success',
      data: null
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 提交客户审批
router.post('/:id/submit', async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    
    customer.status = '待审批';
    await customer.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: customer._id,
        status: customer.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 撤销客户申请
router.post('/:id/cancel', async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    
    customer.status = '草稿';
    await customer.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: customer._id,
        status: customer.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 客户审批
router.post('/:id/approve', async (req, res) => {
  try {
    const { action, remark } = req.body;
    
    if (!action || !remark) {
      return res.status(400).json({ code: 5004, message: '审批备注不能为空', data: null });
    }
    
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    
    customer.status = action === 'approve' ? '已审批' : '已驳回';
    await customer.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: customer._id,
        status: customer.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

module.exports = router;