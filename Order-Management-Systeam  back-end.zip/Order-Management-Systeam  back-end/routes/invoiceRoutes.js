const express = require('express');
const router = express.Router();
const Invoice = require('../models/Invoice');
const Contract = require('../models/Contract');

// 生成发票编号
function generateInvoiceNo() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `INV${year}${month}${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`;
}

// 开票录入
router.post('/', async (req, res) => {
  try {
    const { contractId, invoiceAmount, invoiceDate, remark } = req.body;
    
    // 检查合同是否存在
    const contract = await Contract.findById(contractId);
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    // 计算已开票金额
    const existingInvoices = await Invoice.find({ contractId });
    const invoicedAmount = existingInvoices.reduce((sum, invoice) => sum + invoice.invoiceAmount, 0);
    
    // 检查开票金额是否超过合同金额
    if (invoicedAmount + invoiceAmount > contract.contractAmount) {
      return res.status(400).json({ code: 5003, message: '开票金额超过合同金额', data: null });
    }
    
    // 生成发票编号
    let invoiceNo;
    let existingInvoice;
    do {
      invoiceNo = generateInvoiceNo();
      existingInvoice = await Invoice.findOne({ invoiceNo });
    } while (existingInvoice);
    
    const invoice = new Invoice({
      invoiceNo,
      contractId,
      contractNo: contract.contractNo,
      invoiceAmount,
      invoiceDate: invoiceDate ? new Date(invoiceDate) : new Date(),
      remark
    });
    
    await invoice.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: invoice._id,
        invoiceNo: invoice.invoiceNo,
        contractNo: invoice.contractNo,
        invoiceAmount: invoice.invoiceAmount
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 欠票查询
router.get('/query', async (req, res) => {
  try {
    const { contractNo, customerName, page = 1, pageSize = 10 } = req.query;
    
    // 构建合同查询条件
    const contractQuery = {};
    if (contractNo) contractQuery.contractNo = { $regex: contractNo, $options: 'i' };
    if (customerName) contractQuery.customerName = { $regex: customerName, $options: 'i' };
    
    // 获取符合条件的合同
    const contracts = await Contract.find(contractQuery)
      .skip((page - 1) * pageSize)
      .limit(Number(pageSize));
    
    const total = await Contract.countDocuments(contractQuery);
    
    // 计算每个合同的开票情况
    const list = await Promise.all(contracts.map(async (contract) => {
      const invoices = await Invoice.find({ contractId: contract._id });
      const invoicedAmount = invoices.reduce((sum, invoice) => sum + invoice.invoiceAmount, 0);
      const remainingAmount = contract.contractAmount - invoicedAmount;
      
      return {
        contractId: contract._id,
        contractNo: contract.contractNo,
        contractName: contract.contractName,
        customerName: contract.customerName,
        contractAmount: contract.contractAmount,
        invoicedAmount,
        remainingAmount
      };
    }));
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        list,
        total,
        page: Number(page),
        pageSize: Number(pageSize)
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 合同开票详情
router.get('/contract/:id', async (req, res) => {
  try {
    const contract = await Contract.findById(req.params.id);
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    // 获取合同的所有发票
    const invoices = await Invoice.find({ contractId: contract._id });
    const invoicedAmount = invoices.reduce((sum, invoice) => sum + invoice.invoiceAmount, 0);
    const remainingAmount = contract.contractAmount - invoicedAmount;
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        contractId: contract._id,
        contractNo: contract.contractNo,
        contractAmount: contract.contractAmount,
        invoicedAmount,
        remainingAmount,
        invoices: invoices.map(invoice => ({
          id: invoice._id,
          invoiceNo: invoice.invoiceNo,
          invoiceAmount: invoice.invoiceAmount,
          invoiceDate: invoice.invoiceDate,
          remark: invoice.remark
        }))
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

module.exports = router;
