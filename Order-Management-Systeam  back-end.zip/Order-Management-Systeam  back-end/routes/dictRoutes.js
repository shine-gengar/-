const express = require('express');
const router = express.Router();

// 行业列表
router.get('/industries', (req, res) => {
  const industries = [
    "信息技术",
    "金融服务",
    "制造业",
    "零售",
    "医疗健康",
    "教育",
    "其他"
  ];
  
  res.json({
    code: 200,
    message: 'success',
    data: industries
  });
});

// 客户类型列表
router.get('/customer-types', (req, res) => {
  const customerTypes = [
    "企业客户",
    "个人客户",
    "政府客户",
    "其他"
  ];
  
  res.json({
    code: 200,
    message: 'success',
    data: customerTypes
  });
});

// 合同类型列表
router.get('/contract-types', (req, res) => {
  const contractTypes = [
    "产品销售合同",
    "服务合同",
    "采购合同",
    "其他合同"
  ];
  
  res.json({
    code: 200,
    message: 'success',
    data: contractTypes
  });
});

module.exports = router;
