const express = require('express');
const router = express.Router();
const Contract = require('../models/Contract');
const Customer = require('../models/Customer');

// 生成合同编号
function generateContractNo() {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  return `C${year}${month}${String(Math.floor(Math.random() * 10000)).padStart(4, '0')}`;
}

// 合同列表查询
router.get('/', async (req, res) => {
  try {
    const { contractNo, customerName, contractType, status, page = 1, pageSize = 10 } = req.query;
    
    const query = {};
    if (contractNo) query.contractNo = { $regex: contractNo, $options: 'i' };
    if (customerName) query.customerName = { $regex: customerName, $options: 'i' };
    if (contractType) query.contractType = contractType;
    if (status) query.status = status;
    
    const total = await Contract.countDocuments(query);
    const list = await Contract.find(query)
      .skip((page - 1) * pageSize)
      .limit(Number(pageSize))
      .sort({ createdAt: -1 });
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        list,
        total,
        page: Number(page),
        pageSize: Number(pageSize)
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 待审批合同列表
router.get('/pending', async (req, res) => {
  try {
    const { page = 1, pageSize = 10 } = req.query;
    
    const total = await Contract.countDocuments({ status: '待审批' });
    const list = await Contract.find({ status: '待审批' })
      .skip((page - 1) * pageSize)
      .limit(Number(pageSize))
      .sort({ createdAt: -1 });
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        list,
        total,
        page: Number(page),
        pageSize: Number(pageSize)
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 合同详情
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // 检查 ID 是否有效
    if (!id || id === 'undefined' || id === 'null') {
      return res.status(400).json({ code: 400, message: '无效的合同 ID', data: null });
    }
    
    let contract;
    try {
      // 尝试按 ObjectId 查找
      contract = await Contract.findById(id);
    } catch (err) {
      // 如果是 ObjectId 格式错误，返回合同不存在
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    res.json({
      code: 200,
      message: 'success',
      data: contract
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 合同开票详情
router.get('/:id/invoices', async (req, res) => {
  try {
    const { id } = req.params;
    
    // 检查 ID 是否有效
    if (!id || id === 'undefined' || id === 'null') {
      return res.status(400).json({ code: 400, message: '无效的合同 ID', data: null });
    }
    
    let contract;
    try {
      // 尝试按 ObjectId 查找
      contract = await Contract.findById(id);
    } catch (err) {
      // 如果是 ObjectId 格式错误，返回合同不存在
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    // 获取合同的所有发票
    const Invoice = require('../models/Invoice');
    const invoices = await Invoice.find({ contractId: contract._id });
    const invoicedAmount = invoices.reduce((sum, invoice) => sum + invoice.invoiceAmount, 0);
    const remainingAmount = contract.contractAmount - invoicedAmount;
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        contractId: contract._id,
        contractNo: contract.contractNo,
        contractAmount: contract.contractAmount,
        invoicedAmount,
        remainingAmount,
        invoices: invoices.map(invoice => ({
          id: invoice._id,
          invoiceNo: invoice.invoiceNo,
          invoiceAmount: invoice.invoiceAmount,
          invoiceDate: invoice.invoiceDate,
          remark: invoice.remark
        }))
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 新增合同
router.post('/', async (req, res) => {
  try {
    const { contractName, signDate, deliveryDate, contractType, contractAmount, customerId } = req.body;
    
    // 检查客户是否存在
    const customer = await Customer.findById(customerId);
    if (!customer) {
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    
    // 生成合同编号
    let contractNo;
    let existingContract;
    do {
      contractNo = generateContractNo();
      existingContract = await Contract.findOne({ contractNo });
    } while (existingContract);
    
    const contract = new Contract({
      contractNo,
      contractName,
      signDate: new Date(signDate),
      deliveryDate: new Date(deliveryDate),
      contractType,
      contractAmount,
      customerId,
      customerName: customer.customerName,
      status: '待审批'
    });
    
    await contract.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: contract._id,
        contractNo: contract.contractNo,
        contractName: contract.contractName,
        status: contract.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 修改合同
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { contractName, signDate, deliveryDate, contractType, contractAmount, customerId } = req.body;
    
    // 检查 ID 是否有效
    if (!id || id === 'undefined' || id === 'null') {
      return res.status(400).json({ code: 400, message: '无效的合同 ID', data: null });
    }
    
    let contract;
    try {
      // 尝试按 ObjectId 查找
      contract = await Contract.findById(id);
    } catch (err) {
      // 如果是 ObjectId 格式错误，返回合同不存在
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    // 检查客户是否存在
    const customer = await Customer.findById(customerId);
    if (!customer) {
      return res.status(404).json({ code: 404, message: '客户不存在', data: null });
    }
    
    // 更新合同信息
    contract.contractName = contractName;
    contract.signDate = new Date(signDate);
    contract.deliveryDate = new Date(deliveryDate);
    contract.contractType = contractType;
    contract.contractAmount = contractAmount;
    contract.customerId = customerId;
    contract.customerName = customer.customerName;
    contract.status = '待审批';
    
    await contract.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: contract._id,
        contractNo: contract.contractNo,
        contractName: contract.contractName,
        status: contract.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 删除合同
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    
    // 检查 ID 是否有效
    if (!id || id === 'undefined' || id === 'null') {
      return res.status(400).json({ code: 400, message: '无效的合同 ID', data: null });
    }
    
    let contract;
    try {
      // 尝试按 ObjectId 查找
      contract = await Contract.findById(id);
    } catch (err) {
      // 如果是 ObjectId 格式错误，返回合同不存在
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    await contract.deleteOne();
    
    res.json({
      code: 200,
      message: 'success',
      data: null
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 提交合同审批
router.post('/:id/submit', async (req, res) => {
  try {
    const { id } = req.params;
    
    // 检查 ID 是否有效
    if (!id || id === 'undefined' || id === 'null') {
      return res.status(400).json({ code: 400, message: '无效的合同 ID', data: null });
    }
    
    let contract;
    try {
      // 尝试按 ObjectId 查找
      contract = await Contract.findById(id);
    } catch (err) {
      // 如果是 ObjectId 格式错误，返回合同不存在
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    contract.status = '待审批';
    await contract.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: contract._id,
        status: contract.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 撤销合同申请
router.post('/:id/cancel', async (req, res) => {
  try {
    const { id } = req.params;
    
    // 检查 ID 是否有效
    if (!id || id === 'undefined' || id === 'null') {
      return res.status(400).json({ code: 400, message: '无效的合同 ID', data: null });
    }
    
    let contract;
    try {
      // 尝试按 ObjectId 查找
      contract = await Contract.findById(id);
    } catch (err) {
      // 如果是 ObjectId 格式错误，返回合同不存在
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    contract.status = '草稿';
    await contract.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: contract._id,
        status: contract.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

// 合同审批
router.post('/:id/approve', async (req, res) => {
  try {
    const { id } = req.params;
    const { action, remark } = req.body;
    
    // 检查 ID 是否有效
    if (!id || id === 'undefined' || id === 'null') {
      return res.status(400).json({ code: 400, message: '无效的合同 ID', data: null });
    }
    
    if (!action || !remark) {
      return res.status(400).json({ code: 5004, message: '审批备注不能为空', data: null });
    }
    
    let contract;
    try {
      // 尝试按 ObjectId 查找
      contract = await Contract.findById(id);
    } catch (err) {
      // 如果是 ObjectId 格式错误，返回合同不存在
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    if (!contract) {
      return res.status(404).json({ code: 404, message: '合同不存在', data: null });
    }
    
    contract.status = action === 'approve' ? '已审批' : '已驳回';
    await contract.save();
    
    res.json({
      code: 200,
      message: 'success',
      data: {
        id: contract._id,
        status: contract.status
      }
    });
  } catch (err) {
    res.status(500).json({ code: 500, message: '服务器内部错误', data: null });
  }
});

module.exports = router;