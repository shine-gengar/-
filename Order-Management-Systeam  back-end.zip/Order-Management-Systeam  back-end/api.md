# 订单管理系统后端接口文档
这是基于nodejs的后端项目  数据库连接方式是mongodb://root:oHG40613so7nK78t@project-db-mongodb.ns-xqaidghh.svc:27017
本文档列出了前端项目需要的所有后端接口，包括接口路径、请求方法、参数和返回数据结构。

## 1. 客户管理模块

### 1.1 客户列表查询

**接口路径**: `/api/customers`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| customerName | string | 否 | 客户名称 |
| customerShortName | string | 否 | 客户简称 |
| industry | string | 否 | 行业 |
| customerType | string | 否 | 客户类型 |
| contactPerson | string | 否 | 联系人 |
| contactPhone | string | 否 | 联系电话 |
| customerAddress | string | 否 | 客户地址 |
| page | number | 否 | 页码，默认1 |
| pageSize | number | 否 | 每页数量，默认10 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "id": 1,
        "customerName": "北京科技有限公司",
        "customerShortName": "北京科技",
        "industry": "信息技术",
        "customerType": "企业客户",
        "contactPerson": "张三",
        "contactPhone": "13800138001",
        "customerAddress": "北京市海淀区中关村",
        "status": "已审批",
        "createdAt": "2024-12-01 10:00:00"
      }
    ],
    "total": 10,
    "page": 1,
    "pageSize": 10
  }
}
```

### 1.2 客户详情

**接口路径**: `/api/customers/{id}`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 客户ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "customerName": "北京科技有限公司",
    "customerShortName": "北京科技",
    "industry": "信息技术",
    "customerType": "企业客户",
    "contactPerson": "张三",
    "contactPhone": "13800138001",
    "customerAddress": "北京市海淀区中关村",
    "status": "已审批",
    "createdAt": "2024-12-01 10:00:00",
    "updatedAt": "2024-12-01 10:00:00"
  }
}
```

### 1.3 新增客户

**接口路径**: `/api/customers`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| customerName | string | 是 | 客户名称 |
| customerShortName | string | 否 | 客户简称 |
| industry | string | 是 | 行业 |
| customerType | string | 是 | 客户类型 |
| contactPerson | string | 是 | 联系人 |
| contactPhone | string | 是 | 联系电话 |
| customerAddress | string | 否 | 客户地址 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "customerName": "北京科技有限公司",
    "status": "待审批"
  }
}
```

### 1.4 修改客户

**接口路径**: `/api/customers/{id}`
**请求方法**: `PUT`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 客户ID |
| customerName | string | 是 | 客户名称 |
| customerShortName | string | 否 | 客户简称 |
| industry | string | 是 | 行业 |
| customerType | string | 是 | 客户类型 |
| contactPerson | string | 是 | 联系人 |
| contactPhone | string | 是 | 联系电话 |
| customerAddress | string | 否 | 客户地址 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "customerName": "北京科技有限公司",
    "status": "待审批"
  }
}
```

### 1.5 删除客户

**接口路径**: `/api/customers/{id}`
**请求方法**: `DELETE`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 客户ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": null
}
```

### 1.6 提交客户审批

**接口路径**: `/api/customers/{id}/submit`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 客户ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "status": "待审批"
  }
}
```

### 1.7 撤销客户申请

**接口路径**: `/api/customers/{id}/cancel`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 客户ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "status": "草稿"
  }
}
```

### 1.8 客户审批

**接口路径**: `/api/customers/{id}/approve`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 客户ID |
| action | string | 是 | 审批动作（approve/reject） |
| remark | string | 是 | 审批备注 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "status": "已审批" // 或 "已驳回"
  }
}
```

### 1.9 待审批客户列表

**接口路径**: `/api/customers/pending`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| page | number | 否 | 页码，默认1 |
| pageSize | number | 否 | 每页数量，默认10 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "id": 1,
        "customerName": "北京科技有限公司",
        "customerShortName": "北京科技",
        "industry": "信息技术",
        "customerType": "企业客户",
        "contactPerson": "张三",
        "contactPhone": "13800138001",
        "customerAddress": "北京市海淀区中关村",
        "status": "待审批",
        "createdAt": "2024-12-01 10:00:00"
      }
    ],
    "total": 5,
    "page": 1,
    "pageSize": 10
  }
}
```

## 2. 合同管理模块

### 2.1 合同列表查询

**接口路径**: `/api/contracts`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| contractNo | string | 否 | 合同编号 |
| customerName | string | 否 | 客户名称 |
| contractType | string | 否 | 合同类型 |
| status | string | 否 | 合同状态 |
| page | number | 否 | 页码，默认1 |
| pageSize | number | 否 | 每页数量，默认10 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "id": 1,
        "contractNo": "C202412001",
        "contractName": "产品销售合同",
        "signDate": "2024-12-01",
        "deliveryDate": "2024-12-31",
        "contractType": "产品销售合同",
        "contractAmount": 100000,
        "customerName": "北京科技有限公司",
        "status": "已审批",
        "createdAt": "2024-12-01 10:00:00"
      }
    ],
    "total": 10,
    "page": 1,
    "pageSize": 10
  }
}
```

### 2.2 合同详情

**接口路径**: `/api/contracts/{id}`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 合同ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "contractNo": "C202412001",
    "contractName": "产品销售合同",
    "signDate": "2024-12-01",
    "deliveryDate": "2024-12-31",
    "contractType": "产品销售合同",
    "contractAmount": 100000,
    "customerName": "北京科技有限公司",
    "status": "已审批",
    "createdAt": "2024-12-01 10:00:00",
    "updatedAt": "2024-12-01 10:00:00"
  }
}
```

### 2.3 新增合同

**接口路径**: `/api/contracts`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| contractName | string | 是 | 合同名称 |
| signDate | string | 是 | 签订日期（YYYY-MM-DD） |
| deliveryDate | string | 是 | 交货日期（YYYY-MM-DD） |
| contractType | string | 是 | 合同类型 |
| contractAmount | number | 是 | 合同金额 |
| customerId | number | 是 | 客户ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "contractNo": "C202412001",
    "contractName": "产品销售合同",
    "status": "待审批"
  }
}
```

### 2.4 修改合同

**接口路径**: `/api/contracts/{id}`
**请求方法**: `PUT`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 合同ID |
| contractName | string | 是 | 合同名称 |
| signDate | string | 是 | 签订日期（YYYY-MM-DD） |
| deliveryDate | string | 是 | 交货日期（YYYY-MM-DD） |
| contractType | string | 是 | 合同类型 |
| contractAmount | number | 是 | 合同金额 |
| customerId | number | 是 | 客户ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "contractNo": "C202412001",
    "contractName": "产品销售合同",
    "status": "待审批"
  }
}
```

### 2.5 删除合同

**接口路径**: `/api/contracts/{id}`
**请求方法**: `DELETE`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 合同ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": null
}
```

### 2.6 提交合同审批

**接口路径**: `/api/contracts/{id}/submit`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 合同ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "status": "待审批"
  }
}
```

### 2.7 撤销合同申请

**接口路径**: `/api/contracts/{id}/cancel`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 合同ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "status": "草稿"
  }
}
```

### 2.8 合同审批

**接口路径**: `/api/contracts/{id}/approve`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 合同ID |
| action | string | 是 | 审批动作（approve/reject） |
| remark | string | 是 | 审批备注 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "status": "已审批" // 或 "已驳回"
  }
}
```

### 2.9 待审批合同列表

**接口路径**: `/api/contracts/pending`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| page | number | 否 | 页码，默认1 |
| pageSize | number | 否 | 每页数量，默认10 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "id": 1,
        "contractNo": "C202412001",
        "contractName": "产品销售合同",
        "signDate": "2024-12-01",
        "deliveryDate": "2024-12-31",
        "contractType": "产品销售合同",
        "contractAmount": 100000,
        "customerName": "北京科技有限公司",
        "status": "待审批",
        "createdAt": "2024-12-01 10:00:00"
      }
    ],
    "total": 5,
    "page": 1,
    "pageSize": 10
  }
}
```

## 3. 开票管理模块

### 3.1 开票录入

**接口路径**: `/api/invoices`
**请求方法**: `POST`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| contractId | number | 是 | 合同ID |
| invoiceAmount | number | 是 | 开票金额 |
| invoiceDate | string | 否 | 开票日期（YYYY-MM-DD） |
| remark | string | 否 | 发票备注 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "id": 1,
    "invoiceNo": "INV202412001",
    "contractNo": "C202412001",
    "invoiceAmount": 50000
  }
}
```

### 3.2 欠票查询

**接口路径**: `/api/invoices/query`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| contractNo | string | 否 | 合同编号 |
| customerName | string | 否 | 客户名称 |
| page | number | 否 | 页码，默认1 |
| pageSize | number | 否 | 每页数量，默认10 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "list": [
      {
        "contractId": 1,
        "contractNo": "C202412001",
        "contractName": "产品销售合同",
        "customerName": "北京科技有限公司",
        "contractAmount": 100000,
        "invoicedAmount": 50000,
        "remainingAmount": 50000
      }
    ],
    "total": 10,
    "page": 1,
    "pageSize": 10
  }
}
```

### 3.3 合同开票详情

**接口路径**: `/api/contracts/{id}/invoices`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| id | number | 是 | 合同ID |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": {
    "contractId": 1,
    "contractNo": "C202412001",
    "contractAmount": 100000,
    "invoicedAmount": 50000,
    "remainingAmount": 50000,
    "invoices": [
      {
        "id": 1,
        "invoiceNo": "INV202412001",
        "invoiceAmount": 50000,
        "invoiceDate": "2024-12-10",
        "remark": "首批货款"
      }
    ]
  }
}
```

## 4. 公共模块

### 4.1 行业列表

**接口路径**: `/api/dicts/industries`
**请求方法**: `GET`
**参数**: 无

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": [
    "信息技术",
    "金融服务",
    "制造业",
    "零售",
    "医疗健康",
    "教育",
    "其他"
  ]
}
```

### 4.2 客户类型列表

**接口路径**: `/api/dicts/customer-types`
**请求方法**: `GET`
**参数**: 无

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": [
    "企业客户",
    "个人客户",
    "政府客户",
    "其他"
  ]
}
```

### 4.3 合同类型列表

**接口路径**: `/api/dicts/contract-types`
**请求方法**: `GET`
**参数**: 无

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": [
    "产品销售合同",
    "服务合同",
    "采购合同",
    "其他合同"
  ]
}
```

### 4.4 客户选择列表

**接口路径**: `/api/customers/select`
**请求方法**: `GET`
**参数**:
| 参数名 | 类型 | 必填 | 描述 |
|--------|------|------|------|
| keyword | string | 否 | 搜索关键词 |

**返回数据**:
```json
{
  "code": 200,
  "message": "success",
  "data": [
    {
      "id": 1,
      "customerName": "北京科技有限公司",
      "customerShortName": "北京科技",
      "industry": "信息技术",
      "customerType": "企业客户",
      "contactPerson": "张三",
      "contactPhone": "13800138001"
    }
  ]
}
```

## 5. 接口返回格式说明

所有接口返回统一格式：

```json
{
  "code": 200, // 状态码，200表示成功，其他表示失败
  "message": "success", // 提示信息
  "data": {} // 数据内容
}
```

## 6. 错误码说明

| 错误码 | 描述 |
|--------|------|
| 400 | 请求参数错误 |
| 401 | 未授权 |
| 403 | 禁止访问 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |
| 5001 | 客户名称已存在 |
| 5002 | 合同编号已存在 |
| 5003 | 开票金额超过合同金额 |
| 5004 | 审批备注不能为空 |
