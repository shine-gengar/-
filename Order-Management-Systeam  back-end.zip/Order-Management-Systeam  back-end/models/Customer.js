const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  customerName: {
    type: String,
    required: true,
    unique: true
  },
  customerShortName: {
    type: String
  },
  industry: {
    type: String,
    required: true
  },
  customerType: {
    type: String,
    required: true
  },
  contactPerson: {
    type: String,
    required: true
  },
  contactPhone: {
    type: String,
    required: true
  },
  customerAddress: {
    type: String
  },
  status: {
    type: String,
    enum: ['草稿', '待审批', '已审批', '已驳回'],
    default: '草稿'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Customer', customerSchema);
