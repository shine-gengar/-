const mongoose = require('mongoose');

const contractSchema = new mongoose.Schema({
  contractNo: {
    type: String,
    unique: true
  },
  contractName: {
    type: String,
    required: true
  },
  signDate: {
    type: Date,
    required: true
  },
  deliveryDate: {
    type: Date,
    required: true
  },
  contractType: {
    type: String,
    required: true
  },
  contractAmount: {
    type: Number,
    required: true
  },
  customerId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Customer',
    required: true
  },
  customerName: {
    type: String
  },
  status: {
    type: String,
    enum: ['草稿', '待审批', '已审批', '已驳回'],
    default: '草稿'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Contract', contractSchema);
